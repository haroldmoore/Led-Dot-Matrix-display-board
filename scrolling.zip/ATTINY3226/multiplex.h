


#include <Arduino.h>

void glow_all();

void off_all();

void glow_led(int ledNumber);

void off_led(int ledNumber);

void print_pattern(int print_array[7][5]);

void disp_char(char c);

void disp_custom_char(int print_array[7][5]);

void glow_led_scroll(int);

void off_led_scroll(int);

void glow_matrix_scroll(char);

void disp_char_scroll(char c);
